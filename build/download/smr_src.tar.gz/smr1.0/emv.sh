# choose in Delta and Tinaroo
## Delta
export local="/shares/common/users/zhili.zheng/local/.local2"
export MKLROOT="/shares/compbio/Group-Yang/zl/local/intel/compilers_and_libraries/linux/mkl"

## Tinaroo & Flashlite
#export local="/gpfs1/scratch/90days/uqzzhen4/local/.local"
#export MKLROOT="/gpfs1/scratch/90days/uqzzhen4/local/intel/compilers_and_libraries/linux/mkl"

# GCC settings
export PATH="$local/bin:$PATH"
export EIGEN3_INCLUDE_DIR="$local/include/eigen3"
export BOOST_LIB="$local/include"
export CC=gcc-7
export CXX=g++-7

export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8
############end of code######

